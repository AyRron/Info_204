

<?php









/*4−fermeturedelaconnexion*/
mysqli_close($conn);




?>