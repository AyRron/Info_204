

<?php


/*1−Connexionalabase*/

$conn=mysqli_connect("localhost","l2","L2","Cyril");
mysqli_set_charset($conn,"utf8");





?>