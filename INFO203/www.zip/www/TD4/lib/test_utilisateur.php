<?php


include 'connexion.php';
include 'utilisateur.crud.php';


create_jou($conn, 'Olivier', 'Maxime', 'Suède', 26);


?>

