<?php


include 'connexion.php';
include 'partie.crud.php';

create_par($conn, 'Kasparov', 'Deep Blue', 1, 0, 1968);
echo 'Je sais pas si ça marche'
?>